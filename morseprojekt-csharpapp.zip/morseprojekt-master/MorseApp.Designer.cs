﻿namespace MorseProjekt4._0 {
    partial class MorseApp {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.tbInputWord = new System.Windows.Forms.TextBox();
            this.btnSend = new System.Windows.Forms.Button();
            this.lblCoded = new System.Windows.Forms.Label();
            this.lblDecoded = new System.Windows.Forms.Label();
            this.lblInputWord = new System.Windows.Forms.Label();
            this.lblInputCode = new System.Windows.Forms.Label();
            this.tbInputCoded = new System.Windows.Forms.TextBox();
            this.btnSendCoded = new System.Windows.Forms.Button();
            this.cbPort = new System.Windows.Forms.ComboBox();
            this.btnOpenPort = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // tbInputWord
            // 
            this.tbInputWord.Location = new System.Drawing.Point(162, 64);
            this.tbInputWord.Name = "tbInputWord";
            this.tbInputWord.Size = new System.Drawing.Size(329, 20);
            this.tbInputWord.TabIndex = 0;
            // 
            // btnSend
            // 
            this.btnSend.Location = new System.Drawing.Point(277, 90);
            this.btnSend.Name = "btnSend";
            this.btnSend.Size = new System.Drawing.Size(92, 34);
            this.btnSend.TabIndex = 1;
            this.btnSend.Text = "Send Word";
            this.btnSend.UseVisualStyleBackColor = true;
            this.btnSend.Click += new System.EventHandler(this.btnSend_Click);
            // 
            // lblCoded
            // 
            this.lblCoded.AutoSize = true;
            this.lblCoded.Location = new System.Drawing.Point(289, 232);
            this.lblCoded.Name = "lblCoded";
            this.lblCoded.Size = new System.Drawing.Size(67, 13);
            this.lblCoded.TabIndex = 2;
            this.lblCoded.Text = "Coded Word";
            // 
            // lblDecoded
            // 
            this.lblDecoded.AutoSize = true;
            this.lblDecoded.Location = new System.Drawing.Point(284, 256);
            this.lblDecoded.Name = "lblDecoded";
            this.lblDecoded.Size = new System.Drawing.Size(80, 13);
            this.lblDecoded.TabIndex = 3;
            this.lblDecoded.Text = "Decoded Word";
            // 
            // lblInputWord
            // 
            this.lblInputWord.AutoSize = true;
            this.lblInputWord.Location = new System.Drawing.Point(159, 48);
            this.lblInputWord.Name = "lblInputWord";
            this.lblInputWord.Size = new System.Drawing.Size(57, 13);
            this.lblInputWord.TabIndex = 4;
            this.lblInputWord.Text = "Input word";
            // 
            // lblInputCode
            // 
            this.lblInputCode.AutoSize = true;
            this.lblInputCode.Location = new System.Drawing.Point(159, 144);
            this.lblInputCode.Name = "lblInputCode";
            this.lblInputCode.Size = new System.Drawing.Size(278, 13);
            this.lblInputCode.TabIndex = 6;
            this.lblInputCode.Text = "Input coded word (Write in the following format: \"...;---;...\")";
            // 
            // tbInputCoded
            // 
            this.tbInputCoded.Location = new System.Drawing.Point(162, 160);
            this.tbInputCoded.Name = "tbInputCoded";
            this.tbInputCoded.Size = new System.Drawing.Size(329, 20);
            this.tbInputCoded.TabIndex = 5;
            // 
            // btnSendCoded
            // 
            this.btnSendCoded.Location = new System.Drawing.Point(277, 186);
            this.btnSendCoded.Name = "btnSendCoded";
            this.btnSendCoded.Size = new System.Drawing.Size(92, 34);
            this.btnSendCoded.TabIndex = 7;
            this.btnSendCoded.Text = "Send Coded Word";
            this.btnSendCoded.UseVisualStyleBackColor = true;
            this.btnSendCoded.Click += new System.EventHandler(this.btnSendCoded_Click);
            // 
            // cbPort
            // 
            this.cbPort.FormattingEnabled = true;
            this.cbPort.Items.AddRange(new object[] {
            "COM1",
            "COM2",
            "COM3",
            "COM4",
            "COM5",
            "COM6",
            "COM7",
            "COM8"});
            this.cbPort.Location = new System.Drawing.Point(162, 12);
            this.cbPort.Name = "cbPort";
            this.cbPort.Size = new System.Drawing.Size(160, 21);
            this.cbPort.TabIndex = 8;
            // 
            // btnOpenPort
            // 
            this.btnOpenPort.Location = new System.Drawing.Point(340, 12);
            this.btnOpenPort.Name = "btnOpenPort";
            this.btnOpenPort.Size = new System.Drawing.Size(151, 21);
            this.btnOpenPort.TabIndex = 9;
            this.btnOpenPort.Text = "Open port";
            this.btnOpenPort.UseVisualStyleBackColor = true;
            this.btnOpenPort.Click += new System.EventHandler(this.btnOpenPort_Click);
            // 
            // MorseApp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(659, 303);
            this.Controls.Add(this.btnOpenPort);
            this.Controls.Add(this.cbPort);
            this.Controls.Add(this.btnSendCoded);
            this.Controls.Add(this.lblInputCode);
            this.Controls.Add(this.tbInputCoded);
            this.Controls.Add(this.lblInputWord);
            this.Controls.Add(this.lblDecoded);
            this.Controls.Add(this.lblCoded);
            this.Controls.Add(this.btnSend);
            this.Controls.Add(this.tbInputWord);
            this.Name = "MorseApp";
            this.Text = "MorseApp";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbInputWord;
        private System.Windows.Forms.Button btnSend;
        private System.Windows.Forms.Label lblCoded;
        private System.Windows.Forms.Label lblDecoded;
        private System.Windows.Forms.Label lblInputWord;
        private System.Windows.Forms.Label lblInputCode;
        private System.Windows.Forms.TextBox tbInputCoded;
        private System.Windows.Forms.Button btnSendCoded;
        private System.Windows.Forms.ComboBox cbPort;
        private System.Windows.Forms.Button btnOpenPort;
    }
}

