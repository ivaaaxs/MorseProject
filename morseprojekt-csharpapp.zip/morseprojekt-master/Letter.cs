namespace MorseProjekt4._0
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Letter
    {
        public int Id { get; set; }

        [Required]
        [StringLength(50)]
        public string Decoded { get; set; }

        [Required]
        [StringLength(50)]
        public string Coded { get; set; }

        public override string ToString() {
            return Coded.ToString();
        }
    }
}
