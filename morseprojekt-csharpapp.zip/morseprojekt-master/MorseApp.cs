﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MorseProjekt4._0 {
    public partial class MorseApp : Form {

        private Letters letters = new Letters();
        private Engine engine; // = new Engine();
        public MorseApp() {
            InitializeComponent();
        }

        private void btnSend_Click(object sender, EventArgs e) {
            lblCoded.Text = letters.Encode(tbInputWord.Text).ToString();
            lblDecoded.Text = tbInputWord.Text.ToString();

            engine.SendMessage(tbInputWord.Text);

            //engine.Send(letters.Encode(tbInput.Text).ToString());
        }

        private void btnSendCoded_Click(object sender, EventArgs e) {
            lblCoded.Text = tbInputCoded.Text.ToString();
            lblDecoded.Text = letters.Decode(tbInputCoded.Text).ToString();

            engine.testSendMessage(tbInputCoded.Text);
        }

        private void btnOpenPort_Click(object sender, EventArgs e) {
            engine = new Engine(cbPort.Text);
            engine.MessageReceived += MessageReceived;
        }

        public void MessageReceived(object sender, MessageReceivedEventArgs e) {
            if (lblDecoded.InvokeRequired) {
                lblDecoded.Invoke(new MethodInvoker(delegate {
                    lblDecoded.Text = e.Message;
                    lblCoded.Text = letters.Encode(e.Message).ToString();
                }));
            } else {
                lblDecoded.Text = e.Message;
                lblCoded.Text = letters.Encode(e.Message).ToString();
            }
        }
    }
}
