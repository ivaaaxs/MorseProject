using System;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Linq;

namespace MorseProjekt4._0 {
    public partial class LetterDbContext : DbContext {
        public LetterDbContext()
            : base("name=LetterDbContext") {
        }

        public virtual DbSet<Letter> Letters { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder) {
            modelBuilder.Entity<Letter>()
                .Property(e => e.Decoded)
                .IsUnicode(false);

            modelBuilder.Entity<Letter>()
                .Property(e => e.Coded)
                .IsUnicode(false);
        }
    }
}
