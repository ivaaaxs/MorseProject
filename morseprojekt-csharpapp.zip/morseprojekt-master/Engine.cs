﻿using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MorseProjekt4._0 {
    public class Engine {
        private SerialPort serialPort;
        private Letters letters;
        private string received = "";
        
        // TODO: Pararametri za port
        public Engine(string port) {
            serialPort = new SerialPort(port, 19200, Parity.None, 8, StopBits.One); //COM PORT PROMIJENITI!!! (ako nije taj)
            try {
                serialPort.Open();
            } catch (Exception) {
                MessageBox.Show("Port nije otvoren!");
            }
            letters = new Letters();
            serialPort.DataReceived += DataReceived;
        }

        private void DataReceived(object sender, SerialDataReceivedEventArgs e) {
            SerialPort sp = (SerialPort)sender;
            string indata = sp.ReadExisting();
            //MessageBox.Show(indata);
            for (int i = 0; i < indata.Length; i++) {
                if (indata[i] == '\r') {
                    received += indata[i];
                    if (received.Trim().Length != 0) {
                        //MessageBox.Show(letters.Decode(received).ToString());
                        MessageReceived(this, new MessageReceivedEventArgs(letters.Decode(received).ToString()));
                    }
                    received = "";
                } else {
                    received += indata[i];
                }
            }
        }

        // event for received message
        public delegate void MessageReceivedEventHandler(object sender, MessageReceivedEventArgs e);
        public event MessageReceivedEventHandler MessageReceived;

        public void SendMessage(string message) {
            //serialPort.Write(letters.Encode(message).ToString());
            SendEncodedMessage(letters.Encode(message).ToString());
        }

        public void SendEncodedMessage(string encodedMessage) {
            serialPort.Write(encodedMessage);
        }

        public void testSendMessage(string message) {
            string testMsg = letters.DecodeInputed(message).ToString();
            SendEncodedMessage(letters.Encode(testMsg).ToString());
        }
    }
}
