﻿select * from letters

insert into letters (decoded, coded) values ('B', '-...');

insert into letters (decoded, coded) values ('B', '-...');

insert into letters (decoded, coded) values ('C', '-.-.');
insert into letters (decoded, coded) values ('D', '-..');
insert into letters (decoded, coded) values ('E', '.');
insert into letters (decoded, coded) values ('F', '..-.');
insert into letters (decoded, coded) values ('G', '--.');
insert into letters (decoded, coded) values ('H', '....');
insert into letters (decoded, coded) values ('I', '..');
insert into letters (decoded, coded) values ('J', '.---');
insert into letters (decoded, coded) values ('K', '-.-');
insert into letters (decoded, coded) values ('L', '.-..');
insert into letters (decoded, coded) values ('M', '--');
insert into letters (decoded, coded) values ('N', '-.');
insert into letters (decoded, coded) values ('O', '---');
insert into letters (decoded, coded) values ('P', '.--.');
insert into letters (decoded, coded) values ('Q', '--.-');
insert into letters (decoded, coded) values ('R', '.-.');
insert into letters (decoded, coded) values ('S', '...');
insert into letters (decoded, coded) values ('T', '-');
insert into letters (decoded, coded) values ('U', '..-');
insert into letters (decoded, coded) values ('V', '...-');
insert into letters (decoded, coded) values ('W', '.--');
insert into letters (decoded, coded) values ('X', '-..-');
insert into letters (decoded, coded) values ('Y', '-.--');
insert into letters (decoded, coded) values ('Z', '--..');