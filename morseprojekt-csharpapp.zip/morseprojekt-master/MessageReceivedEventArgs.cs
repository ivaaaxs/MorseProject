﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MorseProjekt4._0 {
    public class MessageReceivedEventArgs {
        public string Message { get; set; }

        public MessageReceivedEventArgs(string message) {
            Message = message;
        }
    }
}
