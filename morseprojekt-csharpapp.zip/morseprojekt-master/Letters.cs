﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MorseProjekt4._0 {
    public class Letters {
        private SortedDictionary<string, string> lettersCd;
        private SortedDictionary<string, string> lettersDc;

        public Letters() {
            var context = new LetterDbContext();
            lettersCd = new SortedDictionary<string, string>();
            lettersDc = new SortedDictionary<string, string>();


            var letter =
                from l in context.Letters
                select l;

            foreach (var l in letter) {
                lettersCd.Add(l.Coded, l.Decoded);
                lettersDc.Add(l.Decoded, l.Coded);
            }
        }

        public StringBuilder Encode(string str) {

            StringBuilder word = new StringBuilder();

            foreach (char c in str) {
                word.Append(lettersDc[c.ToString().ToUpper()]);
                word.Append(";");
            }

            word[word.Length - 1] = '\r';

            return word;
        }

        public StringBuilder Decode(string str) {
            List<string> cLetters = str.Split(';').ToList<string>();
            StringBuilder word = new StringBuilder();

            string result = cLetters.Last().Remove(cLetters.Last().Length - 1); //dohvacamo zadnji string u listi i brisemo r
            //string result = last.Remove(last.Length - 1); //brisemo /

            cLetters.RemoveAt(cLetters.Count() - 1); //brisemo zadnji string sa "/r" na kraju

            cLetters.Add(result); //dodajemo string bez "/r"

            foreach (string letter in cLetters) {
                //try i catch ako ne postoji u dictionaryu
                try {
                    word.Append(lettersCd[letter]);
                } catch (KeyNotFoundException) {
                    word.Append("?");
                }
            }
            return word;
        }

        public StringBuilder DecodeInputed(string str) {
            List<string> cLetters = str.Split(';').ToList<string>();
            StringBuilder word = new StringBuilder();

            foreach (string letter in cLetters) {
                //try i catch ako ne postoji u dictionaryu
                try {
                    word.Append(lettersCd[letter]);
                } catch (Exception) {
                    word.Append("?");
                }
            }
            return word;
        }
    }
}
